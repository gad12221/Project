# Name
Gadi Alkalay

# My Knowledge

HTML5,CSS, Sass, Bootstrap.


# Responsive-personal_portfolio
This portfolio contains the code for my personal portfolio website built using HTML, CSS, Bootstrap, Sass. The portfolio showcases my skills, projects, and accomplishments.

# The College where I study

HackerU 
